/*
 * This file is part of spark.
 *
 *  Copyright (c) lucko (Luck) <luck@lucko.me>
 *  Copyright (c) contributors
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package me.lucko.spark.common.util.classfinder;

import com.google.common.collect.ImmutableList;
import org.jspecify.annotations.Nullable;

public interface ClassFinder {

    /**
     * Creates a ClassFinder that combines the results of multiple other finders.
     *
     * @param finders the other class finders
     * @return the combined class finder
     */
    static ClassFinder combining(ClassFinder... finders) {
        return new CombinedClassFinder(ImmutableList.copyOf(finders));
    }

    /**
     * Attempts to find a class by name.
     *
     * @param className the name of the class
     * @return the class, if found
     */
    @Nullable Class<?> findClass(String className);

}
